# Contributing to DevStackBox

Thank you for your interest in contributing to DevStackBox.

## Table of Contents

- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Project Structure](#project-structure)
- [Development Guidelines](#development-guidelines)
- [Submitting Changes](#submitting-changes)
- [Reporting Issues](#reporting-issues)

## Getting Started

DevStackBox is built with:

- **Backend**: Tauri (Rust)
- **Frontend**: Vite + React + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Animations**: Framer Motion
- **i18n**: i18next (English & Hindi)

## Development Setup

### Prerequisites

- Node.js 24 LTS and npm (the app tracks package-lock.json)
- Current stable Rust with the Windows MSVC build tools
- Windows 11 (primary development/test platform)

### Installation

```bash
git clone https://github.com/DevStackBox/DevStackBox.git
cd DevStackBox
npm ci
pnpm tauri dev
```

### Build for Production

Configure the private updater signing key and follow [the release runbook](docs/development/release-runbook.mdx).

```bash
npm run build:release
```

## 📂 Project Structure

```
DevStackBox/
├── src/              # React frontend
│   ├── components/   # UI components (shadcn/ui)
│   ├── pages/        # Page components
│   ├── lib/          # Utilities & i18n
│   └── hooks/        # Custom React hooks
├── src-tauri/        # Rust backend
│   ├── src/          # Tauri commands & service management
│   └── capabilities/ # Tauri permissions
├── config/           # Server config files (httpd.conf, my.cnf, etc.)
├── locales/          # i18next translations (en.json, hi.json)
└── scripts/          # Build & preparation scripts
```

## Development Guidelines

Documentation lives in `docs/` as MDX. When you add or rename a page, update `docs/navigation.ts` in the same pull request. The website at [devstackbox.com/docs](https://www.devstackbox.com/docs) is built from this folder by [DevStackBox-Website](https://github.com/DevStackBox/DevStackBox-Website).

Follow [docs/development/coding-standards.mdx](docs/development/coding-standards.mdx) for user-facing copy (also published on the website).

### UI/UX Rules

- **Only use Tailwind CSS and shadcn/ui** - No custom CSS unless absolutely necessary
- **Dark/light mode required** - All components must support both themes
- **Use Framer Motion** for animations (not CSS keyframes)
- **Responsive design** - Test on different screen sizes

### Code Style

- **TypeScript**: Use strict typing, no `any` unless necessary
- **Rust**: Follow standard Rust conventions, use `cargo fmt`
- **Components**: Keep components small and focused
- **i18n**: All user-facing text must use `t()` from i18next

### Copilot Best Practices

See [.github/copilot-instructions.md](.github/copilot-instructions.md) for detailed GitHub Copilot usage guidelines.

## 🔧 Key Features to Implement

Priority features (see README.md for full list):

1. **Apache Server Management** (High Priority)
2. **Logs Viewer** with real-time updates
3. **Config Editor** with Monaco
4. **Auto-Updater** integration
5. **Database Backup/Restore**

## 📤 Submitting Changes

1. **Fork** the repository
2. **Create a branch**: `git checkout -b feature/your-feature-name`
3. **Make your changes** following the guidelines above
4. **Test thoroughly** on Windows 11
5. **Commit**: Use clear, descriptive commit messages
6. **Push**: `git push origin feature/your-feature-name`
7. **Create a Pull Request** with detailed description

### PR Guidelines

- Reference related issues
- Include screenshots/videos for UI changes
- Ensure all tests pass
- Update documentation if needed

## 🐛 Reporting Issues

Use [GitHub Issues](https://github.com/DevStackBox/DevStackBox/issues) to report:

- Bugs
- Feature requests
- Documentation improvements

For security vulnerabilities, follow [SECURITY.md](SECURITY.md) and email **hello@devstackbox.com** - do not open a public issue.

### Bug Report Template

```markdown
**Environment:**

- DevStackBox Version:
- OS: Windows 11
- Installation Method: NSIS (.exe); include whether this was a clean install or upgrade

**Description:**
Clear description of the bug

**Steps to Reproduce:**

1. Step 1
2. Step 2
3. ...

**Expected Behavior:**
What should happen

**Actual Behavior:**
What actually happens

**Screenshots:**
If applicable
```

## 📞 Contact

- **Author**: Nomad Programmer
- **Email**: hello@devstackbox.com
- **GitHub**: [DevStackBox/DevStackBox](https://github.com/DevStackBox/DevStackBox)

---

Thank you for contributing to DevStackBox!
