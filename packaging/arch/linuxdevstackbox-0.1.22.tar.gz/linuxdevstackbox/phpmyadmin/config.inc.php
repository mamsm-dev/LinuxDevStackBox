<?php
/**
 * phpMyAdmin Configuration for DevStackBox
 * Copied to phpmyadmin/config.inc.php by the bundle and refresh scripts.
 */

// Server configuration
$cfg['Servers'][1]['auth_type'] = 'cookie';
$cfg['Servers'][1]['host'] = '127.0.0.1';
$cfg['Servers'][1]['port'] = 3306;
$cfg['Servers'][1]['connect_type'] = 'tcp';
$cfg['Servers'][1]['compress'] = false;
$cfg['Servers'][1]['user'] = 'root';
$cfg['Servers'][1]['password'] = '';
$cfg['Servers'][1]['AllowNoPassword'] = true;
$cfg['Servers'][1]['AllowRoot'] = true;

// Directories with correct paths for DevStackBox
$cfg['UploadDir'] = 'D:/Websites/DevStackBox/review-artifacts/documentation/profile/phpmyadmin/upload';
$cfg['SaveDir'] = 'D:/Websites/DevStackBox/review-artifacts/documentation/profile/phpmyadmin/save';
$cfg['TempDir'] = 'D:/Websites/DevStackBox/review-artifacts/documentation/profile/phpmyadmin/tmp';

// Security settings
$cfg['blowfish_secret'] = 'nYSd6wlCE7kRo3kX5o4gAZ03zEWpiaLK';
$cfg['DefaultLang'] = 'en';
$cfg['ServerDefault'] = 1;

// Performance settings
$cfg['MaxRows'] = 100;
$cfg['MemoryLimit'] = '512M';
$cfg['ExecTimeLimit'] = 600;

// UI settings
$cfg['ShowPhpInfo'] = true;
$cfg['ShowServerInfo'] = true;
$cfg['ShowAll'] = true;
$cfg['MaxNavigationItems'] = 200;

// Theme
$cfg['ThemeDefault'] = 'pmahomme';

// phpMyAdminImportConfigVersion: 1
