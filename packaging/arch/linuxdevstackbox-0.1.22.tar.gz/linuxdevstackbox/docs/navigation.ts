/**
 * Single source of truth for documentation sidebar and site footer links.
 * Update this file in the same PR when adding or removing doc pages.
 */

export type NavItem = {
  title: string;
  slug: string;
  children?: NavItem[];
};

export type NavSection = {
  title: string;
  items: NavItem[];
};

export const docsNav: NavSection[] = [
  {
    title: "Getting Started",
    items: [
      { title: "Overview", slug: "" },
      { title: "Installation", slug: "getting-started/installation" },
      { title: "Upgrading", slug: "getting-started/upgrading" },
      { title: "Projects, PHP & HTTPS", slug: "getting-started/projects" },
    ],
  },
  {
    title: "Using DevStackBox",
    items: [
      { title: "Application guide map", slug: "user-guide/application-map" },
      { title: "Dashboard", slug: "user-guide/dashboard" },
      { title: "Services", slug: "user-guide/services" },
      { title: "PHP and extensions", slug: "user-guide/php" },
      { title: "Configuration editor", slug: "user-guide/configuration-editor" },
      { title: "Local HTTPS", slug: "user-guide/local-https" },
      { title: "Databases and users", slug: "user-guide/databases" },
      { title: "SQL import, export and backups", slug: "user-guide/database-backups" },
      { title: "Full backup and restore", slug: "user-guide/full-backup" },
      { title: "Logs", slug: "user-guide/logs" },
      { title: "Terminal", slug: "user-guide/terminal" },
      { title: "Security checks", slug: "user-guide/security" },
      { title: "Settings, tray and About", slug: "user-guide/settings" },
      { title: "XAMPP migration", slug: "user-guide/xampp-migration" },
    ],
  },
  {
    title: "Advanced",
    items: [
      { title: "Environment", slug: "advanced/environment" },
      { title: "Troubleshooting", slug: "advanced/troubleshooting" },
    ],
  },
  {
    title: "Reference",
    items: [
      { title: "Configuration", slug: "reference/configuration" },
      { title: "Commands", slug: "reference/commands" },
      { title: "Installer", slug: "reference/installer" },
    ],
  },
  {
    title: "Development",
    items: [
      { title: "Building", slug: "development/building" },
      { title: "Architecture", slug: "development/architecture" },
      { title: "Components", slug: "development/components" },
      { title: "Coding Standards", slug: "development/coding-standards" },
      { title: "Release Process", slug: "development/release-process" },
      { title: "Release Runbook", slug: "development/release-runbook" },
      { title: "Testing", slug: "development/testing" },
      {
        title: "Architecture Decisions",
        slug: "development/adr",
        children: [
          { title: "ADR Index", slug: "development/adr" },
          { title: "001 - Use Tauri", slug: "development/adr/001-use-tauri" },
          {
            title: "002 - Tailwind + shadcn",
            slug: "development/adr/002-use-tailwind-shadcn",
          },
          { title: "003 - No Redux", slug: "development/adr/003-no-redux" },
          {
            title: "004 - Polling over events",
            slug: "development/adr/004-polling-over-events",
          },
          {
            title: "005 - PHP-first scope",
            slug: "development/adr/005-php-first-scope",
          },
          {
            title: "006 - App/data separation",
            slug: "development/adr/006-app-data-separation",
          },
        ],
      },
    ],
  },
  {
    title: "Project",
    items: [
      { title: "Roadmap", slug: "roadmap" },
      { title: "Feature Status", slug: "feature-status" },
      { title: "FAQ", slug: "faq" },
    ],
  },
];

export const siteHeaderNav = [
  { label: "Download", href: "/download" },
  { label: "Docs", href: "/docs" },
  { label: "Releases", href: "/releases" },
  { label: "Community", href: "/community" },
] as const;

export const siteFooterNav = {
  documentation: [
    { label: "Documentation", href: "/docs" },
    { label: "Download", href: "/download" },
    { label: "Releases", href: "/releases" },
    { label: "Roadmap", href: "/docs/roadmap" },
    { label: "Changelog", href: "/changelog" },
    { label: "FAQ", href: "/docs/faq" },
  ],
  community: [
    {
      label: "GitHub",
      href: "https://github.com/DevStackBox/DevStackBox",
      external: true,
    },
    {
      label: "Contributing",
      href: "https://github.com/DevStackBox/DevStackBox/blob/main/CONTRIBUTING.md",
      external: true,
    },
    { label: "Code of Conduct", href: "/community#code-of-conduct" },
  ],
  legal: [
    { label: "License", href: "/license" },
    { label: "Privacy", href: "/privacy" },
    { label: "Security", href: "/security" },
  ],
} as const;

/** Flat ordered list of doc slugs for prev/next navigation and orphan checks. */
export function flattenDocSlugs(sections: NavSection[] = docsNav): string[] {
  const slugs: string[] = [];
  for (const section of sections) {
    for (const item of section.items) {
      if (item.children) {
        for (const child of item.children) {
          slugs.push(child.slug);
        }
      } else {
        slugs.push(item.slug);
      }
    }
  }
  return slugs;
}

export const allDocSlugs = flattenDocSlugs();
